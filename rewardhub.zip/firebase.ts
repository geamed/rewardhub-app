// This file can be used for Firebase SDK initialization in the future.
// For now, it's a valid empty module.
export {};
